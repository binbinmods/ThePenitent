# 1.1.0

Update for AtO v1.5 - fixed bugs caused by the update

Made Low Self-Esteem and Void Memory castable injuries.

# 1.0.0

Initial release.