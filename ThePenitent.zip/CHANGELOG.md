# 1.1.1

Fixed OC crash

Cardback no longer shares

# 1.1.0 (Untested Version)

Update for AtO v1.5 - fixed bugs caused by the update

Made Low Self-Esteem and Void Memory castable injuries.

Made Qui Tollis Peccata steal 2 curses and reduce all curses on Cain at end of turn.

Made the Meek Shall Inherit also increase healing.

# 1.0.0

Initial release.